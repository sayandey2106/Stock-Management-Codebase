import React, { Component } from "react";
import RouteCon from "./containers/router/router_cont";

class App extends Component {
  render() {
    return (
      <div>
        <RouteCon />
      </div>
    );
  }
}
export default App;
