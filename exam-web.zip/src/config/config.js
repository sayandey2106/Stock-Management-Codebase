const UNIVERSAL = {
    // BASEURL: "http://localhost:8000/"
    BASEURL: "https://nepal2.herokuapp.com/"
    // BASEURL: "https://qubi-trail.el.r.appspot.com/"
    //     BASEURL: "http://172.25.4.190:8000/"
        // BASEURL: "http://192.168.0.165:8008/"
    // BASEURL: "https://server-bumqe7vyuq-el.a.run.app/"
};
export default UNIVERSAL;
