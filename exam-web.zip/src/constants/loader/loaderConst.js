export const LOADER = 'LOADER';
