export const all_admin_option = [
    {id: 0, name: "Dashboard", icon: "home", link: "/"},
];
export const all_corporate_options = [
    // {id: 0, name: "Home", icon: "home", link: "/"},
    {id: 3, name: "DashBoard", icon: "home", link: "/"},
    // {id: 1, name: "Category", icon: "category", link: "/category"},
    // {id: 2, name: "Request", icon: "request_page", link: "/request"},
    // { id: 2, name: "Users", icon: "group", link: "/users" },
];

// export const all_executive_option = [
//     {id: 0, name: "Home", icon: "home", link: "/"},
//     {id: 1, name: "Workshops", icon: "handyman", link: "/workshops"},
//     {id: 2, name: "Webinars", icon: "phonelink", link: "/webinars"},
//     {id: 3, name: "Batches", icon: "people", link: "/batches"}
// ];

// export const all_client_option = [
//   { id: 0, name: "Home", icon: "home", link: "/" },
//   { id: 1, name: "Workshops", icon: "handyman", link: "/workshops" },
//   { id: 2, name: "Webinars", icon: "phonelink", link: "/webinars" },
//   { id: 3, name: "Batches", icon: "people", link: "/batches" }
// ];


// export const all_super_admin_option = [
//     {id: 0, name: "Home", icon: "home", link: "admin_dashboard"},
// ];
