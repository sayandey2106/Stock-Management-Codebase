export const SET_SNACK_BAR = "SET_SNACK_BAR";
export const CLOSE_SNACK_BAR = "CLOSE_SNACK_BAR";
