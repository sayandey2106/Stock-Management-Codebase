export const SET_ALL_USER = "SET_ALL_USER";
export const SET_ALL_LEAD ="SET_ALL_LEAD";
